## Lancer le projet

```bash
mvn spring-boot:run
```

## Endpoints

- `POST /api/books` : créer un livre
- `GET /api/books` : lister les livres
- `GET /api/books/{id}` : récupérer un livre
- `POST /api/loans` : créer un prêt
- `POST /api/loans/{loanId}/return` : retourner un prêt
- `GET /api/students/{studentId}/loans` : consulter les prêts d'un étudiant