package com.example.library.web;

import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.example.library.application.BookApplicationService;
import com.example.library.domain.Book;
import com.example.library.web.dto.BookResponse;
import com.example.library.web.mapper.BookResponseMapper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.context.annotation.Import;
import org.springframework.http.MediaType;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

@WebMvcTest(BookController.class)
@Import(ApiExceptionHandler.class)
class BookControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockitoBean
    private BookApplicationService bookApplicationService;

    @MockitoBean
    private BookResponseMapper bookResponseMapper;

    @Test
    void shouldCreateBook() throws Exception {
        Book book = new Book(1L, "Livre", "Enzo", 5);

        when(bookApplicationService.createBook(anyString(), anyString(), anyInt()))
                .thenReturn(book);
        when(bookResponseMapper.toResponse(book))
                .thenReturn(new BookResponse(1L, "Livre", "Enzo", 5));

        mockMvc.perform(post("/api/books")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                                {
                                  "title": "Livre",
                                  "author": "Enzo",
                                  "stock": 5
                                }
                                """))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.title").value("Livre"));
    }

    @Test
    void shouldReturn400WhenPayloadIsInvalid() throws Exception {
        mockMvc.perform(post("/api/books")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                                {
                                  "title": "",
                                  "author": "",
                                  "stock": 0
                                }
                                """))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.message").value("Requête invalide"))
                .andExpect(jsonPath("$.details.title").exists())
                .andExpect(jsonPath("$.details.author").exists())
                .andExpect(jsonPath("$.details.stock").exists());
    }
}