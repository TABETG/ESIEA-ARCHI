package com.example.library.web.mapper;

import com.example.library.domain.Book;
import com.example.library.web.dto.BookResponse;
import org.mapstruct.Mapper;
import org.mapstruct.MappingConstants;

@Mapper(componentModel = MappingConstants.ComponentModel.SPRING)
public interface BookResponseMapper {
    BookResponse toResponse(Book book);
}