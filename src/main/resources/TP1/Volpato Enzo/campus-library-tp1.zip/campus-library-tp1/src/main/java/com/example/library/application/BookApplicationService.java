package com.example.library.application;

import com.example.library.domain.Book;
import com.example.library.domain.ResourceNotFoundException;
import com.example.library.infrastructure.mapper.BookMapper;
import com.example.library.infrastructure.persistence.BookJpaEntity;
import com.example.library.infrastructure.persistence.BookJpaRepository;
import java.util.List;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class BookApplicationService {

    private final BookJpaRepository bookJpaRepository;
    private final BookMapper mapper;

    public BookApplicationService(BookJpaRepository bookJpaRepository, BookMapper bookMapper) {
        this.bookJpaRepository = bookJpaRepository;
        this.mapper = bookMapper;
    }

    public Book createBook(String title, String author, int stock) {
        Book book = new Book(null, title, author, stock);
        BookJpaEntity savedEntity = bookJpaRepository.save(mapper.toEntity(book));
        return mapper.toDomain(savedEntity);
    }

    @Transactional(readOnly = true)
    public List<Book> getAllBooks() {
        return bookJpaRepository.findAll()
                .stream()
                .map(mapper::toDomain)
                .toList();
    }

    @Transactional(readOnly = true)
    public Book getBookById(Long id) {
        return bookJpaRepository.findById(id)
                .map(mapper::toDomain)
                .orElseThrow(() -> new ResourceNotFoundException("Livre introuvable : " + id));
    }
}
