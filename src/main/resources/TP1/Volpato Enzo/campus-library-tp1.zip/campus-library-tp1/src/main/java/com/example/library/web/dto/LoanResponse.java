package com.example.library.web.dto;

import java.time.LocalDate;

public record LoanResponse(
        Long id,
        Long bookId,
        String bookTitle,
        String studentId,
        LocalDate loanDate,
        LocalDate returnedAt,
        String status
) {
}
