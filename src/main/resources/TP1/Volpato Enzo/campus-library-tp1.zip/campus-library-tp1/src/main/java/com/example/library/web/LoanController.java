package com.example.library.web;

import com.example.library.application.LoanApplicationService;
import com.example.library.application.LoanView;
import com.example.library.web.dto.CreateLoanRequest;
import com.example.library.web.dto.LoanResponse;
import com.example.library.web.mapper.LoanResponseMapper;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import java.util.List;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
@Tag(name = "Loans", description = "Gestion des prêts")
public class LoanController {

    private final LoanApplicationService loanApplicationService;
    private final LoanResponseMapper mapper;

    public LoanController(LoanApplicationService loanApplicationService, LoanResponseMapper mapper) {
        this.loanApplicationService = loanApplicationService;
        this.mapper = mapper;
    }

    @PostMapping("/loans")
    @ResponseStatus(HttpStatus.CREATED)
    @Operation(summary = "Créer un prêt")
    public LoanResponse createLoan(@Valid @RequestBody CreateLoanRequest request) {
        return mapper.toResponse(loanApplicationService.createLoan(request.bookId(), request.studentId()));
    }

    @PostMapping("/loans/{loanId}/return")
    @Operation(summary = "Retourner un prêt")
    public LoanResponse returnLoan(@PathVariable Long loanId) {
        return mapper.toResponse(loanApplicationService.returnLoan(loanId));
    }

    @GetMapping("/students/{studentId}/loans")
    @Operation(summary = "Consulter les prêts d'un étudiant")
    public List<LoanResponse> getStudentLoans(@PathVariable String studentId) {
        return loanApplicationService.getLoansByStudent(studentId)
                .stream()
                .map(mapper::toResponse)
                .toList();
    }
}
