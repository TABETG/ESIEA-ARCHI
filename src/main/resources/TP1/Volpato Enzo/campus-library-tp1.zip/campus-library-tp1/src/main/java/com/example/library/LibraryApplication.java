package com.example.library;

import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.info.Contact;
import io.swagger.v3.oas.annotations.info.Info;
import io.swagger.v3.oas.annotations.info.License;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
@OpenAPIDefinition(
        info = @Info(
                title = "Campus Library Flow API",
                version = "1.0.0",
                description = "API monolithique de gestion des livres et des prêts d'une bibliothèque campus.",
                contact = @Contact(name = "Campus Library Flow"),
                license = @License(name = "Usage pédagogique")
        )
)
public class LibraryApplication {

    public static void main(String[] args) {
        SpringApplication.run(LibraryApplication.class, args);
    }
}
