package com.example.library.domain;

public class Book {

    private final Long id;
    private final String title;
    private final String author;
    private final int stock;

    public Book(Long id, String title, String author, int stock) {
        this.id = id;
        this.title = title;
        this.author = author;
        this.stock = stock;
    }

    public Long getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public String getAuthor() {
        return author;
    }

    public int getStock() {
        return stock;
    }

    public boolean isAvailable(int activeLoanCount) {
        return activeLoanCount < stock;
    }

    public void ensureCanBeLoaned(int activeLoanCount) {
        if (stock <= 0) {
            throw new BusinessException("Le stock du livre doit être supérieur à 0 pour permettre un prêt.");
        }

        if (!isAvailable(activeLoanCount)) {
            throw new BusinessException("Aucun exemplaire disponible pour ce livre.");
        }
    }
}
