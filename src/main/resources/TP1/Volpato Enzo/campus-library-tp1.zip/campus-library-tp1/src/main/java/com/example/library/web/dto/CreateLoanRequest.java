package com.example.library.web.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public record CreateLoanRequest(
        @NotNull(message = "L'identifiant du livre est obligatoire")
        Long bookId,
        @NotBlank(message = "L'identifiant étudiant est obligatoire")
        String studentId
) {
}
