package com.example.library.web.mapper;

import com.example.library.application.LoanView;
import com.example.library.web.dto.LoanResponse;
import org.mapstruct.Mapper;
import org.mapstruct.MappingConstants;

@Mapper(componentModel = MappingConstants.ComponentModel.SPRING)
public interface LoanResponseMapper {
    LoanResponse toResponse(LoanView loan);
}