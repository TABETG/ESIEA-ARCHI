package com.example.library.application;

import com.example.library.domain.Book;
import com.example.library.domain.BusinessException;
import com.example.library.domain.Loan;
import com.example.library.domain.ResourceNotFoundException;
import com.example.library.infrastructure.mapper.BookMapper;
import com.example.library.infrastructure.mapper.LoanMapper;
import com.example.library.infrastructure.persistence.BookJpaEntity;
import com.example.library.infrastructure.persistence.BookJpaRepository;
import com.example.library.infrastructure.persistence.LoanJpaEntity;
import com.example.library.infrastructure.persistence.LoanJpaRepository;
import java.time.LocalDate;
import java.util.List;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class LoanApplicationService {

    private final LoanJpaRepository loanJpaRepository;
    private final BookJpaRepository bookJpaRepository;
    private final BookMapper bookMapper;
    private final LoanMapper loanMapper;

    public LoanApplicationService(
            LoanJpaRepository loanJpaRepository,
            BookJpaRepository bookJpaRepository,
            BookMapper bookMapper,
            LoanMapper loanMapper
    ) {
        this.loanJpaRepository = loanJpaRepository;
        this.bookJpaRepository = bookJpaRepository;
        this.bookMapper = bookMapper;
        this.loanMapper = loanMapper;
    }

    public LoanView createLoan(Long bookId, String studentId) {
        BookJpaEntity bookEntity = bookJpaRepository.findById(bookId)
                .orElseThrow(() -> new ResourceNotFoundException("Livre introuvable : " + bookId));

        if (loanJpaRepository.existsByBook_IdAndStudentIdAndReturnedAtIsNull(bookId, studentId)) {
            throw new BusinessException("Cet étudiant possède déjà un prêt actif pour ce livre.");
        }

        Book book = bookMapper.toDomain(bookEntity);
        int activeLoanCount = loanJpaRepository.countByBook_IdAndReturnedAtIsNull(bookId);
        book.ensureCanBeLoaned(activeLoanCount);

        Loan loan = new Loan(null, bookId, studentId, LocalDate.now(), null);
        LoanJpaEntity savedLoan = loanJpaRepository.save(loanMapper.toEntity(loan, bookEntity));

        return new LoanView(
                savedLoan.getId(),
                bookEntity.getId(),
                bookEntity.getTitle(),
                savedLoan.getStudentId(),
                savedLoan.getLoanDate(),
                savedLoan.getReturnedAt(),
                savedLoan.getReturnedAt() == null ? "ACTIVE" : "RETURNED"
        );
    }

    public LoanView returnLoan(Long loanId) {
        LoanJpaEntity loanEntity = loanJpaRepository.findById(loanId)
                .orElseThrow(() -> new ResourceNotFoundException("Prêt introuvable : " + loanId));

        Loan loan = loanMapper.toDomain(loanEntity);
        loan.markAsReturned(LocalDate.now());

        loanEntity.setReturnedAt(loan.getReturnedAt());
        LoanJpaEntity updatedLoan = loanJpaRepository.save(loanEntity);

        return new LoanView(
                updatedLoan.getId(),
                updatedLoan.getBook().getId(),
                updatedLoan.getBook().getTitle(),
                updatedLoan.getStudentId(),
                updatedLoan.getLoanDate(),
                updatedLoan.getReturnedAt(),
                updatedLoan.getReturnedAt() == null ? "ACTIVE" : "RETURNED"
        );
    }

    @Transactional(readOnly = true)
    public List<LoanView> getLoansByStudent(String studentId) {
        return loanJpaRepository.findByStudentIdOrderByLoanDateDesc(studentId)
                .stream()
                .map(loan -> new LoanView(
                        loan.getId(),
                        loan.getBook().getId(),
                        loan.getBook().getTitle(),
                        loan.getStudentId(),
                        loan.getLoanDate(),
                        loan.getReturnedAt(),
                        loan.getReturnedAt() == null ? "ACTIVE" : "RETURNED"
                ))
                .toList();
    }
}
