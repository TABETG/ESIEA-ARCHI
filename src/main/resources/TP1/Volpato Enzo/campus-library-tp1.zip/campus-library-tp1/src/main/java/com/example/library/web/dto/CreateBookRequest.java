package com.example.library.web.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Positive;

public record CreateBookRequest(
        @NotBlank(message = "Le titre est obligatoire")
        String title,
        @NotBlank(message = "L'auteur est obligatoire")
        String author,
        @Positive(message = "Le stock doit être supérieur à 0")
        int stock
) {
}
