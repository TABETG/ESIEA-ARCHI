package com.example.library.application;

import java.time.LocalDate;

public record LoanView(
        Long id,
        Long bookId,
        String bookTitle,
        String studentId,
        LocalDate loanDate,
        LocalDate returnedAt,
        String status
) {
}
