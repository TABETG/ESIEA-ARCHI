package com.example.library.infrastructure.persistence;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LoanJpaRepository extends JpaRepository<LoanJpaEntity, Long> {

    int countByBook_IdAndReturnedAtIsNull(Long bookId);

    boolean existsByBook_IdAndStudentIdAndReturnedAtIsNull(Long bookId, String studentId);

    List<LoanJpaEntity> findByStudentIdOrderByLoanDateDesc(String studentId);
}
