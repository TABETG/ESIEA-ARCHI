package com.example.library.web;

import com.example.library.application.BookApplicationService;
import com.example.library.domain.Book;
import com.example.library.web.dto.BookResponse;
import com.example.library.web.dto.CreateBookRequest;
import com.example.library.web.mapper.BookResponseMapper;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import java.util.List;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/books")
@Tag(name = "Books", description = "Gestion des livres")
public class BookController {

    private final BookApplicationService bookApplicationService;
    private final BookResponseMapper mapper;

    public BookController(BookApplicationService bookApplicationService, BookResponseMapper mapper) {
        this.bookApplicationService = bookApplicationService;
        this.mapper = mapper;
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    @Operation(summary = "Créer un livre")
    public BookResponse createBook(@Valid @RequestBody CreateBookRequest request) {
        Book createdBook = bookApplicationService.createBook(request.title(), request.author(), request.stock());
        return mapper.toResponse(createdBook);
    }

    @GetMapping
    @Operation(summary = "Lister les livres")
    public List<BookResponse> getAllBooks() {
        return bookApplicationService.getAllBooks()
                .stream()
                .map(mapper::toResponse)
                .toList();
    }

    @GetMapping("/{id}")
    @Operation(summary = "Récupérer un livre par son id")
    public BookResponse getBookById(@PathVariable Long id) {
        return mapper.toResponse(bookApplicationService.getBookById(id));
    }
}
