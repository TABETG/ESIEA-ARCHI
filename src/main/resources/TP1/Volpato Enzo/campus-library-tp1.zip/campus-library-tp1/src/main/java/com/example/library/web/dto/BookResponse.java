package com.example.library.web.dto;

public record BookResponse(
        Long id,
        String title,
        String author,
        int stock
) {
}
