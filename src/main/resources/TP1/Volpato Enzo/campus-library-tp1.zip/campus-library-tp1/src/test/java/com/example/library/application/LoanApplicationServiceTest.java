package com.example.library.application;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import com.example.library.domain.Book;
import com.example.library.domain.BusinessException;
import com.example.library.domain.Loan;
import com.example.library.infrastructure.mapper.BookMapper;
import com.example.library.infrastructure.mapper.LoanMapper;
import com.example.library.infrastructure.persistence.BookJpaEntity;
import com.example.library.infrastructure.persistence.BookJpaRepository;
import com.example.library.infrastructure.persistence.LoanJpaEntity;
import com.example.library.infrastructure.persistence.LoanJpaRepository;
import java.time.LocalDate;
import java.util.Optional;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class LoanApplicationServiceTest {

    @Mock
    private LoanJpaRepository loanJpaRepository;

    @Mock
    private BookJpaRepository bookJpaRepository;

    @Mock
    private BookMapper bookMapper;

    @Mock
    private LoanMapper loanMapper;

    @InjectMocks
    private LoanApplicationService loanApplicationService;

    @Test
    void shouldCreateLoanWhenBookIsAvailable() {
        BookJpaEntity bookEntity = new BookJpaEntity();
        bookEntity.setId(1L);
        bookEntity.setTitle("Livre 1");
        bookEntity.setAuthor("John");
        bookEntity.setStock(2);

        Book book = new Book(1L, "Livre 1", "John", 2);

        LoanJpaEntity savedLoanEntity = new LoanJpaEntity();
        savedLoanEntity.setId(10L);
        savedLoanEntity.setBook(bookEntity);
        savedLoanEntity.setStudentId("001");
        savedLoanEntity.setLoanDate(LocalDate.now());
        savedLoanEntity.setReturnedAt(null);

        when(bookJpaRepository.findById(1L)).thenReturn(Optional.of(bookEntity));
        when(bookMapper.toDomain(bookEntity)).thenReturn(book);
        when(loanJpaRepository.existsByBook_IdAndStudentIdAndReturnedAtIsNull(1L, "001"))
                .thenReturn(false);
        when(loanJpaRepository.countByBook_IdAndReturnedAtIsNull(1L))
                .thenReturn(1);
        when(loanMapper.toEntity(any(Loan.class), any(BookJpaEntity.class)))
                .thenReturn(savedLoanEntity);
        when(loanJpaRepository.save(any(LoanJpaEntity.class)))
                .thenReturn(savedLoanEntity);

        LoanView result = loanApplicationService.createLoan(1L, "001");

        assertThat(result.id()).isEqualTo(10L);
        assertThat(result.bookId()).isEqualTo(1L);
        assertThat(result.status()).isEqualTo("ACTIVE");
    }

    @Test
    void shouldRejectLoanWhenNoCopyIsAvailable() {
        BookJpaEntity bookEntity = new BookJpaEntity();
        bookEntity.setId(1L);
        bookEntity.setTitle("DDD");
        bookEntity.setAuthor("Eric Evans");
        bookEntity.setStock(1);

        Book book = new Book(1L, "DDD", "Eric Evans", 1);

        when(bookJpaRepository.findById(1L)).thenReturn(Optional.of(bookEntity));
        when(bookMapper.toDomain(bookEntity)).thenReturn(book);

        when(loanJpaRepository.existsByBook_IdAndStudentIdAndReturnedAtIsNull(1L, "STU-001"))
                .thenReturn(false);
        when(loanJpaRepository.countByBook_IdAndReturnedAtIsNull(1L))
                .thenReturn(1);

        assertThatThrownBy(() -> loanApplicationService.createLoan(1L, "STU-001"))
                .isInstanceOf(BusinessException.class)
                .hasMessage("Aucun exemplaire disponible pour ce livre.");
    }
}