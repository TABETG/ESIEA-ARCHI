package com.example.library.domain;

import java.time.LocalDate;

public class Loan {

    private final Long id;
    private final Long bookId;
    private final String studentId;
    private final LocalDate loanDate;
    private LocalDate returnedAt;

    public Loan(Long id, Long bookId, String studentId, LocalDate loanDate, LocalDate returnedAt) {
        this.id = id;
        this.bookId = bookId;
        this.studentId = studentId;
        this.loanDate = loanDate;
        this.returnedAt = returnedAt;
    }

    public Long getId() {
        return id;
    }

    public Long getBookId() {
        return bookId;
    }

    public String getStudentId() {
        return studentId;
    }

    public LocalDate getLoanDate() {
        return loanDate;
    }

    public LocalDate getReturnedAt() {
        return returnedAt;
    }

    public boolean isReturned() {
        return returnedAt != null;
    }

    public void markAsReturned(LocalDate returnedDate) {
        if (isReturned()) {
            throw new BusinessException("Ce prêt a déjà été retourné.");
        }
        this.returnedAt = returnedDate;
    }
}
