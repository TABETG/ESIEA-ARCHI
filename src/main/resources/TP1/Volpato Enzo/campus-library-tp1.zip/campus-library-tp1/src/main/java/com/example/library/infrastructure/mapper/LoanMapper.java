package com.example.library.infrastructure.mapper;

import com.example.library.domain.Loan;
import com.example.library.infrastructure.persistence.BookJpaEntity;
import com.example.library.infrastructure.persistence.LoanJpaEntity;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingConstants;

@Mapper(componentModel = MappingConstants.ComponentModel.SPRING)
public interface LoanMapper {

    @Mapping(target = "bookId", source = "entity.book.id")
    Loan toDomain(LoanJpaEntity entity);

    @Mapping(target = "id", source = "loan.id")
    @Mapping(target = "book", source = "bookEntity")
    @Mapping(target = "studentId", source = "loan.studentId")
    @Mapping(target = "loanDate", source = "loan.loanDate")
    @Mapping(target = "returnedAt", source = "loan.returnedAt")
    LoanJpaEntity toEntity(Loan loan, BookJpaEntity bookEntity);
}