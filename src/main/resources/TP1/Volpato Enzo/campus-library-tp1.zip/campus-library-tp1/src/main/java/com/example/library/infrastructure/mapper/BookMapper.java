package com.example.library.infrastructure.mapper;

import com.example.library.domain.Book;
import com.example.library.infrastructure.persistence.BookJpaEntity;
import org.mapstruct.Mapper;
import org.mapstruct.MappingConstants;

@Mapper(componentModel = MappingConstants.ComponentModel.SPRING)
public interface BookMapper {

    Book toDomain(BookJpaEntity entity);

    BookJpaEntity toEntity(Book book);
}